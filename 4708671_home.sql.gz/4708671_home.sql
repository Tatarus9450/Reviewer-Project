-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: fdb1032.awardspace.net    Database: 4708671_home
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Comment`
--

DROP TABLE IF EXISTS `Comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Comment` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `review_id` int NOT NULL,
  `comment_text` text NOT NULL,
  `comment_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`),
  KEY `user_id` (`user_id`),
  KEY `review_id` (`review_id`),
  CONSTRAINT `Comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`),
  CONSTRAINT `Comment_ibfk_2` FOREIGN KEY (`review_id`) REFERENCES `Review` (`review_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comment`
--

LOCK TABLES `Comment` WRITE;
/*!40000 ALTER TABLE `Comment` DISABLE KEYS */;
INSERT INTO `Comment` VALUES (1,2,1,'ขอบคุณสำหรับรีวิวครับ ทางเราดีใจที่คุณชอบ (Admin)','2023-06-01 12:00:00'),(2,1,2,'แนะนำให้สั่งเผื่อ 1 ไซส์ครับ ผมเคยสั่งแล้ว','2023-06-21 09:00:00'),(3,3,3,'เห็นแล้วหิวเลย เดี๋ยวต้องไปตำตาม','2023-07-06 08:00:00'),(5,2,5,'จิงค่ะ ฟันปลอมหนูหลุดเลยค่ะ','2025-11-26 15:12:19'),(6,2,2,'แอดมินใส่ไม่ได้เลยค่ะ พุงปริ้นน','2025-11-26 15:35:53'),(7,7,8,'<33','2025-11-26 19:11:48'),(8,7,8,'gghfghgf','2025-11-26 21:50:07'),(9,7,7,'แอดมินมาเอง','2025-11-26 21:51:12'),(10,10,10,'จริงครับ','2025-11-26 23:23:04'),(11,15,16,'เดเดเด','2025-11-27 01:14:45'),(12,14,16,'ได้ เจอกันที่ร้าน','2025-11-27 01:26:56'),(13,15,16,'เจ้าของร้านบอกมาเอง เนื้อนุ่มเพราะโดนหนอนเจาะ และมันปล่อยเอนไซม์มาย่อยเนื้อ จนนุ่มลิ้น โดนหลอกขายละ','2025-11-27 01:30:20'),(14,11,16,'มั่ว นิ่มเพราะโดนรถทับค่ะ รบกวนพิมอะไรที่เป็นความจริงด้วยนะคะ','2025-11-27 01:32:22'),(15,6,27,'อุ้ย','2025-11-27 01:38:24'),(16,6,27,'ไม้หัก','2025-11-27 01:38:33'),(17,6,27,'แก้เหลือ1ดาวได้ไหมคับบ','2025-11-27 01:38:55'),(18,6,20,'จิง','2025-11-27 01:43:58'),(19,6,35,'ว้าวซ่าาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาา','2025-11-27 01:44:20'),(20,11,36,'เหนียวน้อยกว่าปลาหมึก','2025-11-27 01:45:35'),(21,11,20,'มันไม่ดีแต่หมาดีจัด','2025-11-27 01:46:05'),(22,6,30,'มันอร่อย หรอ???','2025-11-27 01:48:02');
/*!40000 ALTER TABLE `Comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL,
  `product_name` varchar(150) NOT NULL,
  `description` text,
  `category` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `store_id` (`store_id`),
  CONSTRAINT `Product_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `Store` (`store_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` VALUES (1,1,'Wireless Gaming Mouse','เมาส์ไร้สาย RGB ความเร็วสูง','Electronics'),(2,2,'Cotton Indigo Shirt','เสื้อหม้อฮ่อมย้อมคราม เนื้อผ้าฝ้ายแท้','Clothing'),(3,3,'Dried Squid Snacks','ปลาหมึกอบแห้ง รสเผ็ดจัดจ้าน','Food'),(4,4,'หมาล่า ซุปหมา','หมา.. ล่า นำเข้าจากวัด รสนัวMSG','Food'),(5,5,'Signature Dirty Coffee','กาแฟนมแยกชั้น สูตรพิเศษของทางร้าน หอมมัน นุ่มละมุน','Beverage'),(11,9,'Acne Clear Gel','เจลแต้มสิว สูตรเร่งด่วน สิวยุบไว ไม่ทิ้งรอยดำ','Beauty'),(12,11,'ราชันย์ขอบไม้ ราคาจับต้องได้','ชื่อสินค้า: ไม้แบดมินตัน รุ่น \"ราชันย์ขอบไม้\" (The Lord of the Frame Limited Edition)\r\n\r\nรายละเอียดสินค้า (Description): \"ฉีกทุกกฎฟิสิกส์ ท้าทายทุกแรงโน้มถ่วงกับสุดยอดนวัตกรรมแห่งปี 2025 ที่ออกแบบมาเพื่อผู้เล่นสาย \'แม่นขอบ\' โดยเฉพาะ! หากคุณคือคนที่เบื่อหน่ายกับการตีโดนจุด Sweet Spot ตรงกลางไม้ หากคุณรู้สึกว่าเสียง \'ปัง\' มันไพเราะเกินไปและขาดเอกลักษณ์ เราขอเสนอ \'ราชันย์ขอบไม้\' ไม้แบดที่จะเปลี่ยนทุกการตบของคุณให้กลายเป็นศิลเปรอะ\r\n\r\nคุณสมบัติสุดล้ำ (Specifications):\r\n\r\n- Frame Magnet Technology: เทคโนโลยีแม่เหล็กดูดลูกขนไก่เข้าสู่ \'ขอบไม้\' โดยอัตโนมัติ เพิ่มโอกาสการตีโดนขอบขึ้น 300% แม่นยำระดับนาโนเมตร (แม่นขอบนะ ไม่ใช่แม่นเอ็น)\r\n\r\n- Chaos Direction System: เมื่อลูกกระทบขอบไม้ ระบบจะคำนวณวิถีลูกแบบสุ่ม (Random) ทำให้เกิดทิศทางพิศวงที่แม้แต่คนตีเองยังเดาไม่ได้ คู่แข่งยิ่งไม่ต้องพูดถึง... ยืนงงจนขาตายแน่นอน\r\n\r\n- Durable Tank Material: เฟรมไม้ผลิตจากวัสดุเกรดเดียวกับกันชนรถถัง ทนทานต่อแรงกระแทกมหาศาล ไม่ว่าคุณจะตบอัดพื้น ตีบวกกับเพื่อน หรือฟาดเสาเน็ต ไม้ไม่มีวันหัก (แต่แขนคุณอาจจะร้าวแทน)\r\n\r\n- Psychological Warfare Sound: เสียงกระทบขอบ \'โป๊ก!!\' ที่ดังกังวานใสประดุจระฆังวัด ช่วยทำลายสมาธิคู่ต่อสู้ได้ชะงัดนัก ทำให้คู่แข่งขำจนท้องเกร็งและหมดแรงตีไปเอง\r\n\r\n- Zero-Tension Strings: เอ็นขึงไว้เพื่อความสวยงามเท่านั้น เพราะเราเน้นใช้งานพื้นที่รอบนอกเป็นหลัก ประหยัดค่าขึ้นเอ็นตลอดชีพ!\r\n\r\nเหมาะสำหรับ: ผู้เล่นที่ต้องการสร้างตำนาน, ผู้ที่ต้องการโดดเด่นในสนาม, และผู้ที่เชื่อว่า \'ตีเอ็นมันเชย ตีขอบเลยเท่กว่า\'','Sports'),(13,4,'[เนื้อหมาวัด-พันธุ์ไทย]ริมแม่นํ้าเจ้าพระยา[สะโพก]','ตัวเนื้อมีความ เป็นผู้นำในแก๊ง ดุดัน ห้าวหาญ ตีกับหมาบ้านชนะ รสชาติเข้มขมเพราะว่ามีความโตเป็นยอดชายจากชนนบท ฉุ่มฉํ่านํ้าแม่นํ้าเจ้าพระยา [เหมาะสำหรับยอดชายและสาวแตกหนุ่ม]','Food'),(14,4,'[เนื้อหมาลูกคุณหนู-พันธุ์(Pomeranian)]คอนโดย่านสุขุมวิท[สะโพก]','ตัวเนื้อมีความ เป็นตัวเล็ก ขี้อ้อน ขนฟู มีเสน่ห์ และขี้เล่น ตีกับหมาวัดแล้วแพ้ แต่มีผู้ดูแล รสชาติของหมาลูกคุณหนูจะ มีกลิ่นหอมหวานคล้ายนม เพราะยังคงดื่มนมแม่หรือกินอาหารนุ่มๆ ทำให้สะอาดกว่าหมาวัด แต่ไม่แซ่บ [เหมาะสำหรับพวกอ่อนและลูกแหง่]','Food');
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Review`
--

DROP TABLE IF EXISTS `Review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Review` (
  `review_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `rating` int DEFAULT NULL,
  `review_text` text,
  `review_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`review_id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `Review_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `Product` (`product_id`),
  CONSTRAINT `Review_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`),
  CONSTRAINT `Review_chk_1` CHECK (((`rating` >= 1) and (`rating` <= 5)))
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Review`
--

LOCK TABLES `Review` WRITE;
/*!40000 ALTER TABLE `Review` DISABLE KEYS */;
INSERT INTO `Review` VALUES (1,1,1,5,'ใช้ดีมาก ลื่นหัวแตก ไฟสวยคุ้มราคา','2023-06-01 10:00:00'),(2,2,3,4,'ผ้านิ่มใส่สบาย แต่ไซส์เล็กกว่าปกตินิดหน่อย','2023-06-20 11:00:00'),(3,3,1,5,'อร่อยมาก เคี้ยวเพลินจนหยุดไม่ได้','2023-07-05 15:30:00'),(5,3,6,1,'เคี้ยวเพลินมาก เหนียวนุ่มดุจยางรถยนต์','2025-11-26 15:10:06'),(6,3,2,5,'ซื้อไปแล้ว น้องหมาไม่กินคะ ทำไงดี','2025-11-26 15:34:06'),(7,2,2,1,'แย่มาก สั่งXXXXXXLมาก็ยังใส่ไม่ได้','2025-11-26 15:38:44'),(8,2,7,5,'ใส่สบายอยู่นะว่าปายยย','2025-11-26 19:08:02'),(9,3,8,4,'so spicy','2025-11-26 19:08:43'),(10,11,10,5,'ดีมากครับใช้แล้วผมนุ่ม','2025-11-26 23:22:42'),(11,5,8,1,'','2025-11-27 00:11:09'),(12,12,8,5,'','2025-11-27 00:33:14'),(13,12,13,5,'ซื้อมาลองแล้วครับ บอกเลยว่าระบบสุ่มทิศทาง (Chaos Direction) ทำงานดีเกินคาด! ผมตั้งใจเล็งมุมขวาท้ายคอร์ท ตีโดนขอบ \'โป๊ก!\' ลูกพุ่งไซส์โค้งไปตกหน้าเน็ตเฉย คู่แข่งยืนงง กรรมการก็งง ผมก็งง... สรุปชนะบายเพราะคู่แข่งหัวเราะจนเป็นตะคริวครับ 10/10 แนะนำ!','2025-11-27 00:38:45'),(14,12,13,5,'','2025-11-27 00:38:55'),(15,13,14,5,'แซ่บนัว ถึงใจ นํ้าฉํ่าสมคำลือ 😘💕🐶','2025-11-27 00:51:45'),(16,14,15,1,'ไม่สะอาด ไม่อร่อย','2025-11-27 01:14:39'),(17,12,15,2,'','2025-11-27 01:18:14'),(18,13,15,1,'หน้าม้าเยอะจัด','2025-11-27 01:32:15'),(19,13,11,5,'อร่อย อร่อย อร่อย อร่อย','2025-11-27 01:33:02'),(20,13,15,1,'อย่าไปหาลองเรยง่ะ มันมะดี','2025-11-27 01:33:11'),(21,11,11,1,'ไม่อร่อย รสชาติฝาดมาก','2025-11-27 01:34:02'),(22,11,11,5,'','2025-11-27 01:34:06'),(23,4,15,3,'เจอร้านอร่อยกว่านี้อีก','2025-11-27 01:34:30'),(24,11,11,1,'ใช้Acne Clear Gel แล้วนํ้าหนักขึ้น','2025-11-27 01:35:04'),(25,12,11,1,'รสชาติแข็ง ไม่เหมาะกับปลวกที่ชอบไม้นิ่ม','2025-11-27 01:36:10'),(26,12,11,1,'ปลวกบอกอี๋','2025-11-27 01:36:50'),(27,12,6,3,'เอาไปทำกำแพงบ้านสนุกมากครับ คุณย่าผมชอบมาก','2025-11-27 01:38:04'),(28,13,11,5,'เนื้อแซ่บมากครับ','2025-11-27 01:38:19'),(29,14,6,5,'แอดมินชอบมาก อร่อยหมาๆเลยค่ะ','2025-11-27 01:41:33'),(30,1,11,1,'ไม่อร่อย','2025-11-27 01:41:48'),(31,4,6,2,'หมาไม่กิน','2025-11-27 01:42:00'),(32,3,11,5,'ไม่อร่อยเหมือนเนื้อหมา','2025-11-27 01:42:24'),(33,3,11,5,'','2025-11-27 01:42:27'),(34,3,11,1,'เนื้อหมาอร่อยกว่า','2025-11-27 01:42:48'),(35,13,11,5,'เนื้ออร่อย หนักแน่น เป็นตัวเองมากครับ','2025-11-27 01:43:35'),(36,13,6,4,'อร่อยดี แต่เนื้อเหนียวไปหน่อย','2025-11-27 01:43:48'),(37,3,11,5,'รสชาติเหมือนปลาหมึก ไม่เหมือนหมา','2025-11-27 01:44:16'),(38,3,11,1,'เนื้อหมาเหนียวน้อยกว่า','2025-11-27 01:44:46'),(39,1,6,5,'ลื่นหัวแตกกกกก','2025-11-27 01:47:11'),(40,5,17,4,'','2025-11-27 01:52:21'),(41,5,17,3,'ของดี','2025-11-27 01:52:37');
/*!40000 ALTER TABLE `Review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Store`
--

DROP TABLE IF EXISTS `Store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Store` (
  `store_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `store_name` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `register_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`store_id`),
  KEY `fk_store_user_link` (`user_id`),
  CONSTRAINT `fk_store_user_link` FOREIGN KEY (`user_id`) REFERENCES `User` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Store`
--

LOCK TABLES `Store` WRITE;
/*!40000 ALTER TABLE `Store` DISABLE KEYS */;
INSERT INTO `Store` VALUES (1,1,'IT Gadget Pro','Electronics','Thailand','Bangkok','02-123-4567','2023-01-15 09:00:00'),(2,2,'Lanna Textiles','Clothing','Thailand','Chiang Mai','053-987-654','2023-02-20 10:30:00'),(3,3,'Phuket Seafoods','Food','Thailand','Phuket','076-111-222','2023-03-05 14:00:00'),(4,6,'Ploy Mhala','Food','Thailand','Pathum Thani','088-111-9999','2025-11-26 14:00:00'),(5,7,'Moonrise Cafe & Space','Beverage','Thailand','Chiang Mai','081-234-5678','2025-11-20 09:30:00'),(9,8,'Glow Skin & Wellness','Beauty','Thailand','Nonthaburi','02-555-1234','2025-11-24 11:20:00'),(10,6,'Tah Test 99','Others','Thailand','Nonthaburi','0661129450','2025-11-26 23:30:32'),(11,13,'ผมมาขายไม้ขนไก่ไว้ตีแบด','Sports','Thailand','Rangsit','999-999-9999','2025-11-27 00:20:30');
/*!40000 ALTER TABLE `Store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_type_id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `user_type_id` (`user_type_id`),
  CONSTRAINT `User_ibfk_1` FOREIGN KEY (`user_type_id`) REFERENCES `UserType` (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (1,1,'somchai_user','somchai@email.com','pass1234','2023-05-01 08:00:00'),(2,2,'admin_jane','jane.admin@email.com','securepass','2023-01-01 12:00:00'),(3,3,'nong_ploy','ploy@email.com','ploypass','2023-06-15 18:45:00'),(6,2,'talu','talu.khul@bumail.net','12345678','2025-11-26 15:08:49'),(7,1,'miyomui','lalittawadeevongkoon@gmail.com','jayjay','2025-11-26 18:30:27'),(8,1,'granxn','granxn1234@gmail.com','pattypat1234','2025-11-26 19:05:35'),(9,1,'J5W','geegee@rai.com','123555','2025-11-26 23:21:53'),(10,1,'qwert','qwert@gmial.com','12345qwert','2025-11-26 23:21:59'),(11,3,'Ploykai3fong','ariya.rave@bumail.net','Ploy_1212','2025-11-26 23:25:29'),(12,1,'miyomui555','lalittawad@gmail.com','555','2025-11-26 23:33:43'),(13,3,'chonoryokushauser','l@mail.com','555','2025-11-27 00:14:10'),(14,3,'ploykaikuk','ariya@bumail.net','Ploy_1212','2025-11-27 00:14:34'),(15,3,'chonoryokushauser4','fgdfjg@ghfgh','555','2025-11-27 01:13:54'),(16,1,'rrthj','trdet@rrfr','iii','2025-11-27 01:50:48'),(17,1,'iii','iii@iii','iii','2025-11-27 01:51:58'),(18,1,'OSU1O','asdasplkdsa@gmail.com','111111','2025-11-27 01:52:46');
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserType`
--

DROP TABLE IF EXISTS `UserType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserType` (
  `user_type_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL,
  PRIMARY KEY (`user_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserType`
--

LOCK TABLES `UserType` WRITE;
/*!40000 ALTER TABLE `UserType` DISABLE KEYS */;
INSERT INTO `UserType` VALUES (1,'Customer'),(2,'Admin'),(3,'Merchant');
/*!40000 ALTER TABLE `UserType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database '4708671_home'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-26 18:53:23
